﻿appEIS.controller('homeController', function ($scope) {
    $scope.msg = "This is home";
});